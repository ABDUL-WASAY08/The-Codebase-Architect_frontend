const injectButton = () => {
   
    const rows = document.querySelectorAll('.react-directory-filename-column');
    
    rows.forEach(element => {
      
        if (element.querySelector('.CodeBased-analyze-btn')) return;
        
        const anchor = element.querySelector('a');
        if (!anchor) return;

        const btn = document.createElement('button');
        btn.innerText = 'Analyze';
        btn.className = 'CodeBased-analyze-btn';
        btn.style.marginLeft = "10px";
        btn.style.padding = "2px 8px";
        btn.style.fontSize = "12px";
        btn.style.cursor = "pointer";

        btn.onclick = (e) => {
            e.preventDefault(); 
            e.stopPropagation();
            
            const fileLink = anchor.href; 
            const isFolder = fileLink.includes('/tree/');
            const splitKeyword = isFolder ? '/tree/' : '/blob/';
            
            const parts = fileLink.split(splitKeyword);
            const repoUrl = parts[0]; 
            const pathWithBranch = parts[1];

            let filePath = "";
            if (pathWithBranch && pathWithBranch.includes('/')) {
                filePath = pathWithBranch.substring(pathWithBranch.indexOf('/') + 1);
            } else {
                filePath = "";
            }

            const type = isFolder ? 'folder' : 'file';
            const myAppUrl = `https://the-codebase-architect-frontend.vercel.app/Analyzer?repoUrl=${encodeURIComponent(repoUrl)}&filePath=${encodeURIComponent(filePath)}&type=${type}`;
            
            window.open(myAppUrl, '_blank');
        };
        
        element.appendChild(btn);
    });
};
setInterval(injectButton, 2000);