const injectButton = () => {
    // 1. GitHub ke file rows select karna
    const rows = document.querySelectorAll('.react-directory-filename-column');
    
    rows.forEach(element => {
        // Double injection se bachne ke liye check
        if (element.querySelector('.CodeBased-analyze-btn')) return;
        
        const anchor = element.querySelector('a');
        if (!anchor) return;

        const btn = document.createElement('button');
        btn.innerText = 'Analyze';
        btn.className = 'CodeBased-analyze-btn';
        
        // Button Styling (Inline taake CSS ka masla na ho)
        btn.style.marginLeft = "10px";
        btn.style.padding = "2px 8px";
        btn.style.fontSize = "12px";
        btn.style.cursor = "pointer";

        btn.onclick = (e) => {
            e.preventDefault(); 
            e.stopPropagation();
            
            const fileLink = anchor.href; 
            
            // Logic to identify if it's a folder or a file
            const isFolder = fileLink.includes('/tree/');
            const splitKeyword = isFolder ? '/tree/' : '/blob/';
            
            const parts = fileLink.split(splitKeyword);
            const repoUrl = parts[0]; // e.g. https://github.com/user/repo
            const pathWithBranch = parts[1]; // e.g. "main/src/App.js" or just "main"

            let filePath = "";
            
            // Check if there is actually a path after the branch name
            if (pathWithBranch && pathWithBranch.includes('/')) {
                filePath = pathWithBranch.substring(pathWithBranch.indexOf('/') + 1);
            } else {
                // Agar sirf branch name hai (root folder), to path empty string hoga
                filePath = "";
            }

            const type = isFolder ? 'folder' : 'file';
            const myAppUrl = `http://localhost:5173/Analyzer?repoUrl=${encodeURIComponent(repoUrl)}&filePath=${encodeURIComponent(filePath)}&type=${type}`;
            
            window.open(myAppUrl, '_blank');
        };
        
        element.appendChild(btn);
    });
};
setInterval(injectButton, 2000);